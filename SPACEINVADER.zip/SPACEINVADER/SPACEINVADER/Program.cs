﻿using System;
using System.Text;
using Carebear.Field;
    






namespace SPACEINVADER
{
     class Program
    {


        static void Main()
        {
            
            Console.CursorVisible = false;
            Console.WindowWidth = WorkIt.WindowWidth;
            Console.BufferWidth = WorkIt.WindowWidth;
            Console.WindowHeight = WorkIt.WindowHeight;
            Console.BufferHeight = WorkIt.WindowHeight;

            WorkIt wok = new WorkIt();




        }




    }









}






















